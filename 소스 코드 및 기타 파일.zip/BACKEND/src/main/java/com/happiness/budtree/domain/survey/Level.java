package com.happiness.budtree.domain.survey;

public enum Level {
    NORMAL, // 정상
    MINOR, //경미한 수준
    MIDDLE, // 중간 수준
    HEAVY, // 약간 심한 수준
    VIOLENT; //심한 수준

}
