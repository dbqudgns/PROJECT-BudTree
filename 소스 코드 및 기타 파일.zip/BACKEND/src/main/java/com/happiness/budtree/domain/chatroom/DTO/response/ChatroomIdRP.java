package com.happiness.budtree.domain.chatroom.DTO.response;

import lombok.Builder;

@Builder
public record ChatroomIdRP(
        Long roomId
) {
}
