package com.happiness.budtree;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BudtreeApplicationTests {

	@Test
	void contextLoads() {
	}

}
