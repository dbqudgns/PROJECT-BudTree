"use client";

export { ThemeProvider } from "@material-tailwind/react";
